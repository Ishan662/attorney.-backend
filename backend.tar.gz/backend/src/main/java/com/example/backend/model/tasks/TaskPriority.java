package com.example.backend.model.tasks;

public enum TaskPriority {
    HIGH,
    MEDIUM,
    LAW
}
