package com.example.backend.dto.support;

public class CreateSupportMessageRequest {
    private String messageBody;

    public String getMessageBody() { return messageBody; }
    public void setMessageBody(String messageBody) { this.messageBody = messageBody; }
}