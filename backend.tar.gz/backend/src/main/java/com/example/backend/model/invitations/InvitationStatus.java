package com.example.backend.model.invitations;

public enum InvitationStatus {
    PENDING,
    ACCEPTED,
    EXPIRED
}
