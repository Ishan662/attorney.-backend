package com.example.backend.model.subcription;

public enum SubscriptionStatus {
    TRIAL, ACTIVE, CANCELLED, EXPIRED
}
