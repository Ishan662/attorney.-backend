// >> In a new file: model/hearing/HearingStatus.java
package com.example.backend.model.hearing;

public enum HearingStatus {
    PLANNED,
    COMPLETED,
    POSTPONED,
    CANCELLED
}