package com.example.backend.model.support;

public enum SupportCaseStatus {
    OPEN,
    PENDING_USER_REPLY,
    PENDING_ADMIN_REPLY,
    CLOSED
}
