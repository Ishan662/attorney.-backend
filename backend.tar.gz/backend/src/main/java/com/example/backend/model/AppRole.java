package com.example.backend.model;

public enum AppRole {
    ADMIN,
    LAWYER,
    JUNIOR,
    CLIENT,
    RESEARCHER
}